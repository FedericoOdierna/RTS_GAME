﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace RTS_Game
{
    class ResourceBuilding : Building
    {
        private string resourceType;
        private int ticksPerProduction;
        private int resourcesRemaining;

        public ResourceBuilding(int xPos, int yPos, int health, int faction, string symbol)
            : base (xPos, yPos, health, faction, symbol)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.faction = faction;
            this.symbol = "RB";
        }

        private void generateResources()
        {
            if (ticksPerProduction % 5 == 0)
            {
               
            }
        }

        public override void Save()
        {
            FileStream outFile = new FileStream("Files\\ResourceBuilding.txt", FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            writer.WriteLine(xPos);
            writer.WriteLine(yPos);
            writer.WriteLine(health);
            writer.WriteLine(faction);
            writer.WriteLine(symbol);

            writer.Close();
            outFile.Close();
            throw new NotImplementedException();
        }

        public override bool Destruction()
        {
            while (health % 5 == 0)
            {

            }
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            throw new NotImplementedException();
        }

        public override void Read()
        {
            FileStream inFile = null;
            StreamReader reader = null;
            string input;
            int xPos;
            int yPos;
            int health;
            int faction;
            string symbol;
            try
            {
                //open the file
                inFile = new FileStream(@"Files\ResourceBuilding.txt", FileMode.Open, FileAccess.Read);
                reader = new StreamReader(inFile);
                input = reader.ReadLine();      // priming read
                while (input != null)
                {
                    xPos = int.Parse(input);
                    yPos = int.Parse(input);
                    health = int.Parse(input);
                    faction = int.Parse(input);
                    symbol = reader.ReadLine();
                    ResourceBuilding RB = new ResourceBuilding(xPos, yPos, health, faction, symbol);
                    input = reader.ReadLine();      // priming read
                }
                reader.Close();
                inFile.Close();

            }
            catch (Exception fe)
            {
                Debug.WriteLine(fe.Message);        // pus using System.Diagnostics; at the top
            }
            finally
            {
                if (inFile != null)      //park this for now..
                {
                    reader.Close();
                    inFile.Close();
                }
            }
            throw new NotImplementedException();
        }
    }
}
