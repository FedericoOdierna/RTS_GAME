﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS_Game
{
    abstract class Unit
    {
        protected int xPos;
        protected int yPos;
        protected int health;
        protected int speed;
        protected bool attack;
        protected int attackRange;
        protected string faction;
        protected string symbol;

        #region Accessors

        #endregion
        public Unit(int xPos, int yPos, int health, int speed, int attack, int attackRange, int faction, string symbol)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            this.faction = faction;
            this.symbol = symbol;
        }

        public abstract void Move();

        public abstract void Combat();

        public abstract void InAttckRange();

        public abstract void Closer();

        public abstract void Death();

        public abstract void Save();

       /* public string ToString()
        {

            return;
        }
*/
    }
}
