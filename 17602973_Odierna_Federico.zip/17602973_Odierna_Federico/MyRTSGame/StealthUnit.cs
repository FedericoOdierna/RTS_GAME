﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace RTS_Game
{
    class StealthUnit : Unit
    {
        public StealthUnit(int xPos, int yPos, int health, int speed, int attack, int attackRange, int faction, string symbol)
           : base(xPos, yPos, health, speed, attack, attackRange, faction, symbol)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            this.faction = faction;
            this.symbol = symbol;
        }

        public override void Move()
        {
            throw new NotImplementedException();
        }

        public override void Combat()
        {
            throw new NotImplementedException();
        }

        public override void InAttckRange()
        {
            throw new NotImplementedException();
        }

        public override void Closer()
        {
            throw new NotImplementedException();
        }

        public override void Death()
        {
            throw new NotImplementedException();
        }

        public override void Save()
        {
            //Save by creating a folder to save all melee units
            FileStream outFile = new FileStream("Files\\HeavyUnit.txt", FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);

            writer.WriteLine(xPos);
            writer.WriteLine(yPos);
            writer.WriteLine(health);
            writer.WriteLine(speed);
            writer.WriteLine(attack);
            writer.WriteLine(attackRange);
            writer.WriteLine(faction);
            writer.WriteLine(symbol);

            writer.Close();
            outFile.Close();
            throw new NotImplementedException();
        }
    }
}
