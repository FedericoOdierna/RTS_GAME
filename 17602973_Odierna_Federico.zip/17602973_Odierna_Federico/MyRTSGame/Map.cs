﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyRTSGame
{
    class Map
    {
        private int max = 50;
        private string[,] map = new string[20, 20];

        public string InitialiseMap()
        {
            string mapDisplay = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    map[i, j] = "*";
                    mapDisplay += map[i, j];
                }
                mapDisplay += "\n";
            }

            return mapDisplay;
        }

        public void Move()
        {

        }

        public void Update()
        {

        }

        public virtual void Read()
        {

        }
    }
}
