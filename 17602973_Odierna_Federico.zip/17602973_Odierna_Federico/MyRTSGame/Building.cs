﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTS_Game
{
    abstract class Building
    {
        protected int xPos;
        protected int yPos;
        protected int health;
        protected int faction;
        protected string symbol;

        public Building()
        {

        }

        public Building(int xPos, int yPos, int health, int faction, string symbol)
        {
            this.xPos = xPos;
            this.yPos = yPos;
            this.health = health;
            this.faction = faction;
            this.symbol = symbol;
        }

        // creating abstract methods
        public abstract bool Destruction();

        public abstract string ToString();

        public abstract void Save();

        public abstract void Read();
    }
}
